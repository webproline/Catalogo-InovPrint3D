﻿const productsData = {
    dentista: [
        { img: 'Imagens/2.png', title: 'Produto 1' },
        { img: 'Imagens/3.png', title: 'Produto 2' },
        { img: 'Imagens/4.png', title: 'Produto 3' },
        { img: 'Imagens/5.png', title: 'Produto 4' },
        { img: 'Imagens/6.png', title: 'Produto 5' },
        { img: 'Imagens/7.png', title: 'Produto 6' },
        { img: 'Imagens/8.png', title: 'Produto 7' },
        { img: 'Imagens/9.png', title: 'Produto 8' },
        { img: 'Imagens/10.png', title: 'Produto 9' },
        { img: 'Imagens/11.png', title: 'Produto 10' }
    ],
    'cafe-bar': [
        { img: 'images/cafe-bar1.jpg', title: 'Produto 1' },
        { img: 'images/cafe-bar2.jpg', title: 'Produto 2' },
        { img: 'images/cafe-bar3.jpg', title: 'Produto 3' }
    ],
    'colegio-escola': [
        { img: 'images/colegio-escola1.jpg', title: 'Produto 1' },
        { img: 'images/colegio-escola2.jpg', title: 'Produto 2' },
        { img: 'images/colegio-escola3.jpg', title: 'Produto 3' }
    ],
    festas: [
        { img: 'images/festas1.jpg', title: 'Produto 1' },
        { img: 'images/festas2.jpg', title: 'Produto 2' },
        { img: 'images/festas3.jpg', title: 'Produto 3' }
    ]
};

document.addEventListener('DOMContentLoaded', () => {
    const categoryButtons = document.querySelectorAll('.category-btn');
    const productsContainer = document.getElementById('products');

    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.dataset.category;
            displayProducts(category);
        });
    });

    function displayProducts(category) {
        productsContainer.innerHTML = '';
        const products = productsData[category];
        products.forEach(product => {
            const productElement = document.createElement('div');
            productElement.classList.add('product');
            productElement.innerHTML = `
                <img src="${product.img}" alt="${product.title}">
                <p>${product.title}</p>
            `;
            productsContainer.appendChild(productElement);
        });
    }
});